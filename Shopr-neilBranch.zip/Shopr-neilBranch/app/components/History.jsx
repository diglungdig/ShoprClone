var React = require('react');

var History = React.createClass({
  render: function () {
      return (
        <div>
          <h2>
            Loaded from History
          </h2>
        </div>

      );
  }
});

module.exports = History;