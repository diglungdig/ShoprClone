var React = require('react');

var ShoppingCart = React.createClass({
  render: function () {
      return (
        <div>
          <h2>
            Loaded from ShoppingCart
          </h2>
        </div>

      );
  }
});

module.exports = ShoppingCart;