var React = require('react');

var Feedback = React.createClass({
  render: function () {
      return (
        <div>
          <h2>
            Loaded from Feedback
          </h2>
        </div>

      );
  }
});

module.exports = Feedback;